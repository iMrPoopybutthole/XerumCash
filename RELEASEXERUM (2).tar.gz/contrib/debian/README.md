
Debian
====================
This directory contains files used to package XerumCashd/XerumCash-qt
for Debian-based Linux systems. If you compile XerumCashd/XerumCash-qt yourself, there are some useful files here.

## XerumCash: URI support ##


XerumCash-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install XerumCash-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your XerumCash-qt binary to `/usr/bin`
and the `../../share/pixmaps/XerumCash128.png` to `/usr/share/pixmaps`

XerumCash-qt.protocol (KDE)

