Sample configuration files for:

SystemD: XerumCashd.service
Upstart: XerumCashd.conf
OpenRC:  XerumCashd.openrc
         XerumCashd.openrcconf
CentOS:  XerumCashd.init
OS X:    org.XerumCash.XerumCashd.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
